"""WSGI entry point for the Salt Gate checkpoint service.

Served by gunicorn behind the gate's perimeter proxy. For local development
``python wsgi.py`` runs the built-in server on the internal port.
"""

from app import app

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
