"""Tests for the checkpoint routes.

These drive the Flask app directly (no perimeter proxy in front), which is how
a developer exercises the service locally. The outer face is covered here; the
inner desk's provenance rules belong to the perimeter and are exercised in
deployment, not in this in-process test harness.
"""

import os
import tempfile

import pytest


@pytest.fixture()
def client():
    # Point the ledger at a throwaway file so tests never touch a real gate.
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    os.environ["GATE_DB"] = path

    from importlib import reload
    import app as app_pkg
    reload(app_pkg)

    app_pkg.app.config.update(TESTING=True)
    with app_pkg.app.test_client() as client:
        yield client

    os.unlink(path)


def test_ledger_renders(client):
    response = client.get("/app/")
    assert response.status_code == 200
    assert b"Salt Gate" in response.data


def test_present_without_writ_is_turned_away(client):
    response = client.post("/app/gate/present", data={"writ": ""})
    assert response.status_code == 200
    assert b"No writ" in response.data


def test_present_forged_writ_is_turned_away(client):
    response = client.post("/app/gate/present", data={"writ": "forged.token.value"})
    assert response.status_code == 200
    assert b"does not hold" in response.data


def test_inspect_reports_inauthentic_for_garbage(client):
    response = client.get("/app/gate/inspect?writ=nonsense")
    assert response.status_code == 200
    assert response.get_json()["authentic"] is False
