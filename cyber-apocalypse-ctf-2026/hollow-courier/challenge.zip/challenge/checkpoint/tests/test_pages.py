"""Tests for the registry-reading pages: charter, house dossier, status probe.

These cover the read-only faces of the gate. Like the gate tests they drive the
Flask app directly against a throwaway ledger.
"""

import os
import tempfile

import pytest


@pytest.fixture()
def client():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    os.environ["GATE_DB"] = path

    from importlib import reload
    import app as app_pkg
    reload(app_pkg)

    app_pkg.app.config.update(TESTING=True)
    with app_pkg.app.test_client() as client:
        yield client

    os.unlink(path)


def test_charter_renders(client):
    response = client.get("/app/charter")
    assert response.status_code == 200
    assert b"Standing Orders" in response.data


def test_chronicle_desk_sits_on_the_ledger_page(client):
    response = client.get("/app/")
    assert response.status_code == 200
    assert b"The Warden's Chronicle" in response.data
    assert b"js/chronicle.js" in response.data
    # The chronicle is embedded in the ledger rather than served separately.
    assert client.get("/app/chronicle").status_code == 404


def test_house_dossier_renders(client):
    response = client.get("/app/houses/1")
    assert response.status_code == 200
    assert b"Vaultrune" in response.data


def test_unknown_house_is_not_found(client):
    response = client.get("/app/houses/999")
    assert response.status_code == 404
    assert b"Nothing on record" in response.data


def test_status_reports_ok(client):
    response = client.get("/app/status")
    assert response.status_code == 200
    body = response.get_json()
    assert body["status"] == "ok"
    assert body["service"] == "salt-gate"
    assert set(["houses", "writs_passed", "decrees_sealed"]).issubset(body)


def test_login_page_shows_seeded_staff(client):
    response = client.get("/app/login")
    assert response.status_code == 200
    assert b"ashguard" in response.data
    assert b"lantern-guard-1701" in response.data


def test_watch_requires_staff_session(client):
    response = client.get("/app/watch")
    assert response.status_code == 302
    assert "/app/login" in response.headers["Location"]


def test_staff_can_open_watch_desk(client):
    response = client.post(
        "/app/login",
        data={"username": "ashguard", "password": "lantern-guard-1701"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"Watch Desk" in response.data
    assert b"Ashguard Gate-Watch" in response.data


def test_watch_role_cannot_open_audit(client):
    client.post("/app/login", data={"username": "ashguard", "password": "lantern-guard-1701"})
    response = client.get("/app/audit")
    assert response.status_code == 403


def test_clerk_can_open_audit(client):
    client.post("/app/login", data={"username": "lysa", "password": "crown-ledger-8820"})
    response = client.get("/app/audit")
    assert response.status_code == 200
    assert b"Audit Ledger" in response.data


def test_application_has_noisy_route_surface(client):
    app = client.application
    routes = {
        rule.rule for rule in app.url_map.iter_rules()
        if rule.rule.startswith("/app/")
    }
    assert len(routes) >= 20
    assert "/app/roster" in routes
    assert "/app/reports" in routes


def test_public_noise_routes_render(client):
    for path, marker in [
        ("/app/map", b"Gate Map"),
        ("/app/notices", b"Public Notices"),
    ]:
        response = client.get(path)
        assert response.status_code == 200
        assert marker in response.data


def test_staff_can_post_public_notice(client):
    client.post("/app/login", data={"username": "ashguard", "password": "lantern-guard-1701"})
    response = client.post(
        "/app/notices",
        data={"title": "South rail", "body": "South rail opens after bell two."},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"South rail" in response.data
    assert b"Ashguard Gate-Watch" in response.data


def test_staff_noise_routes_require_login(client):
    for path in ["/app/roster", "/app/shifts", "/app/incidents", "/app/supplies"]:
        response = client.get(path)
        assert response.status_code == 302
        assert "/app/login" in response.headers["Location"]


def test_staff_noise_routes_render_after_login(client):
    client.post("/app/login", data={"username": "ashguard", "password": "lantern-guard-1701"})
    for path, marker in [
        ("/app/roster", b"Watch Roster"),
        ("/app/shifts", b"Shift Handover"),
        ("/app/incidents", b"Incident Board"),
        ("/app/supplies", b"Supply Register"),
        ("/app/signals", b"Signal Flags"),
        ("/app/weather", b"Road Weather"),
        ("/app/manifests", b"Cart Manifests"),
        ("/app/inspections", b"Inspection Queue"),
    ]:
        response = client.get(path)
        assert response.status_code == 200
        assert marker in response.data


def test_staff_noise_routes_have_workflows(client):
    client.post("/app/login", data={"username": "ashguard", "password": "lantern-guard-1701"})

    incident = client.post(
        "/app/incidents",
        data={"summary": "Salt cart axle split at the rail", "severity": "medium"},
        follow_redirects=True,
    )
    assert incident.status_code == 200
    assert b"Salt cart axle" in incident.data

    shift = client.post(
        "/app/shifts",
        data={"note": "Bell three handover counted every brass tag."},
        follow_redirects=True,
    )
    assert shift.status_code == 200
    assert b"Bell three handover" in shift.data

    supplies = client.post(
        "/app/supplies",
        data={"item_id": "1", "delta": "3"},
        follow_redirects=True,
    )
    assert supplies.status_code == 200
    assert b"Ink cakes" in supplies.data
    assert b">17<" in supplies.data

    manifest = client.post(
        "/app/manifests",
        data={"cart": "cart-41", "house": "Vaultrune", "goods": "salt panes"},
        follow_redirects=True,
    )
    assert manifest.status_code == 200
    assert b"CART-41" in manifest.data
    assert b"salt panes" in manifest.data

    inspection = client.post(
        "/app/inspections",
        data={"inspection_id": "1", "status": "held"},
        follow_redirects=True,
    )
    assert inspection.status_code == 200
    assert b"held" in inspection.data


def test_privileged_noise_routes_are_role_gated(client):
    client.post("/app/login", data={"username": "ashguard", "password": "lantern-guard-1701"})
    for path in ["/app/keys", "/app/archives", "/app/reports"]:
        assert client.get(path).status_code == 403

    client.post("/app/logout")
    client.post("/app/login", data={"username": "lysa", "password": "crown-ledger-8820"})
    for path, marker in [
        ("/app/keys", b"Key Cabinet"),
        ("/app/archives", b"Archive Index"),
        ("/app/reports", b"Captain Reports"),
    ]:
        response = client.get(path)
        assert response.status_code == 200
        assert marker in response.data


def test_privileged_noise_routes_have_workflows(client):
    client.post("/app/login", data={"username": "lysa", "password": "crown-ledger-8820"})

    keys = client.post(
        "/app/keys",
        data={"key_id": "1", "status": "issued"},
        follow_redirects=True,
    )
    assert keys.status_code == 200
    assert b"Ledger cabinet" in keys.data
    assert b"Lysa Harrowmere" in keys.data

    archives = client.post(
        "/app/archives",
        data={"box_id": "1", "status": "requested"},
        follow_redirects=True,
    )
    assert archives.status_code == 200
    assert b"BOX-A" in archives.data
    assert b"requested" in archives.data

    reports = client.post(
        "/app/reports",
        data={"summary": "Dusk count balanced after the held writ review."},
        follow_redirects=True,
    )
    assert reports.status_code == 200
    assert b"Dusk count balanced" in reports.data
