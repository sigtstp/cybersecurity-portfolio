"""Tests for writ sealing and verification."""

import os
import tempfile

import pytest

from app import auth


def test_sealed_writ_round_trips():
    token = auth.seal_writ("WR-0A19", "Vaultrune Courier", 1)
    payload = auth.verify_writ(token)
    assert payload is not None
    assert payload["serial"] == "WR-0A19"
    assert payload["bearer"] == "Vaultrune Courier"
    assert payload["house_id"] == 1


def test_tampered_writ_is_rejected():
    token = auth.seal_writ("WR-0A19", "Vaultrune Courier", 1)
    # Flip a character in the body of the token; the seal must no longer hold.
    tampered = token[:-2] + ("a" if token[-1] != "a" else "b")
    assert auth.verify_writ(tampered) is None


def test_garbage_is_rejected():
    assert auth.verify_writ("not-a-writ") is None
    assert auth.verify_writ("") is None
