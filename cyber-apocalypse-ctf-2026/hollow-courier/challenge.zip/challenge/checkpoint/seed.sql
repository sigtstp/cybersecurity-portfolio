-- Salt Gate checkpoint ledger -- schema and seed data.
-- Applied once at first start (see app/db.py). Safe to re-run.

CREATE TABLE IF NOT EXISTS houses (
    id        INTEGER PRIMARY KEY,
    name      TEXT NOT NULL UNIQUE,
    sigil     TEXT NOT NULL,
    standing  TEXT NOT NULL DEFAULT 'recognised'
);

CREATE TABLE IF NOT EXISTS writs (
    serial    TEXT PRIMARY KEY,
    bearer    TEXT NOT NULL,
    house_id  INTEGER NOT NULL,
    FOREIGN KEY (house_id) REFERENCES houses(id)
);

CREATE TABLE IF NOT EXISTS passages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    serial      TEXT NOT NULL,
    bearer      TEXT NOT NULL,
    house       TEXT NOT NULL,
    verdict     TEXT NOT NULL,
    recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS decrees (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    writ_serial  TEXT NOT NULL,
    decree_order TEXT NOT NULL,
    sealed_by    TEXT NOT NULL,
    sealed_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS staff_users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    display_name  TEXT NOT NULL,
    role          TEXT NOT NULL,
    pass_hash     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS public_notices (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    title      TEXT NOT NULL,
    body       TEXT NOT NULL,
    posted_by  TEXT NOT NULL,
    posted_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS shift_notes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    note       TEXT NOT NULL,
    posted_by  TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS incidents (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    summary     TEXT NOT NULL,
    severity    TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'open',
    reported_by TEXT NOT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS supplies (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    item       TEXT NOT NULL UNIQUE,
    quantity   INTEGER NOT NULL,
    unit       TEXT NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS manifests (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    cart        TEXT NOT NULL,
    house       TEXT NOT NULL,
    goods       TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'waiting',
    recorded_by TEXT NOT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inspections (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    writ_serial TEXT NOT NULL,
    reason      TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'waiting',
    assigned_to TEXT NOT NULL DEFAULT 'unassigned',
    updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS key_register (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    label      TEXT NOT NULL UNIQUE,
    status     TEXT NOT NULL DEFAULT 'hooked',
    holder     TEXT NOT NULL DEFAULT 'cabinet',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS archive_boxes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    code         TEXT NOT NULL UNIQUE,
    label        TEXT NOT NULL,
    status       TEXT NOT NULL DEFAULT 'shelved',
    requested_by TEXT NOT NULL DEFAULT '',
    updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS daily_reports (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    summary    TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT OR IGNORE INTO houses (id, name, sigil, standing) VALUES
    (1, 'Vaultrune',  'the sealed ledger','recognised'),
    (2, 'Suncourt',   'the sunlit crown', 'crown'),
    (3, 'Eastreach',  'the brass scales', 'recognised'),
    (4, 'Quiet March','the open road',    'watched');

INSERT OR IGNORE INTO writs (serial, bearer, house_id) VALUES
    ('WR-0A19', 'Vaultrune Courier', 1),
    ('WR-0B27', 'Suncourt Factor',   2),
    ('WR-0C44', 'Eastreach Runner',  3),
    ('WR-0D03', 'Quiet March Drover',4);

INSERT OR IGNORE INTO passages (serial, bearer, house, verdict) VALUES
    ('WR-0A19', 'Vaultrune Courier', 'Vaultrune',  'PASSED'),
    ('WR-0C44', 'Eastreach Runner',  'Eastreach',  'PASSED'),
    ('WR-0D03', 'Quiet March Drover','Quiet March','TURNED AWAY');

-- Staff console accounts for the browser UI:
--   ashguard / lantern-guard-1701 (watch)
--   lysa     / crown-ledger-8820  (clerk)
--   garran   / road-watch-4418    (captain)
INSERT OR IGNORE INTO staff_users (username, display_name, role, pass_hash) VALUES
    ('ashguard', 'Ashguard Gate-Watch', 'watch',   'scrypt:32768:8:1$QntPDBp3XriQurdZ$0914635c79b56bdc294da1af9e83e56a19d410fc1df9bde9d9cf2e8c51bfa02c9ae52b480eaaa319d2dc50c4896ed09cd690bf2749dff6488e6d9973bd6d43ca'),
    ('lysa',     'Lysa Harrowmere',      'clerk',   'scrypt:32768:8:1$VDOJFm3UwxL1cqpk$328366465c54b4c4edefe6f83002ff4ef521f7fb930a6c65bd8d1840e4c8d79f6ec23940ac00f1b1e36f69d43f76f73b3e1f545c23ce77a29fd4ee7771a85c34'),
    ('garran',   'Garran Voss',          'captain', 'scrypt:32768:8:1$0MXCEWzguyktrCet$f72d68ca0d5e70a687840ca7636093fd2460df0d6504bbfd28f13119a638e25923ea0b52ecece47941af3a1aa92c468e71b0837460c63633d09f142ece8e1b05');

INSERT OR IGNORE INTO public_notices (id, title, body, posted_by) VALUES
    (1, 'Dusk seal count', 'Trading-day seals expire when the fourth bell fades.', 'Lysa Harrowmere'),
    (2, 'Damaged writs', 'Smudged wax is sent to inspection before any passage is recorded.', 'Ashguard Gate-Watch');

INSERT OR IGNORE INTO shift_notes (id, note, posted_by) VALUES
    (1, 'Dawn watch counted the blank writ slips and found the drawer even.', 'Ashguard Gate-Watch'),
    (2, 'East lantern was trimmed before the low-road carts arrived.', 'Garran Voss');

INSERT OR IGNORE INTO incidents (id, summary, severity, status, reported_by) VALUES
    (1, 'Loose cart pin at the low-road rail', 'low', 'closed', 'Ashguard Gate-Watch'),
    (2, 'Unclear house mark on ash barrel manifest', 'medium', 'open', 'Lysa Harrowmere');

INSERT OR IGNORE INTO supplies (id, item, quantity, unit) VALUES
    (1, 'Ink cakes', 14, 'cakes'),
    (2, 'Salt paper', 8, 'quires'),
    (3, 'Brass tags', 31, 'tags'),
    (4, 'Lantern oil', 6, 'flasks');

INSERT OR IGNORE INTO manifests (id, cart, house, goods, status, recorded_by) VALUES
    (1, 'CART-17', 'Vaultrune', 'tin lamps, road salt', 'cleared', 'Ashguard Gate-Watch'),
    (2, 'CART-22', 'Eastreach', 'sealed ash barrels', 'waiting', 'Lysa Harrowmere');

INSERT OR IGNORE INTO inspections (id, writ_serial, reason, status, assigned_to) VALUES
    (1, 'WR-0D03', 'expired trading day', 'waiting', 'Ashguard Gate-Watch'),
    (2, 'WR-0C44', 'wax seal cracked at the rim', 'cleared', 'Lysa Harrowmere');

INSERT OR IGNORE INTO key_register (id, label, status, holder) VALUES
    (1, 'Ledger cabinet', 'hooked', 'cabinet'),
    (2, 'Lamp room', 'issued', 'Ashguard Gate-Watch'),
    (3, 'Archive drawer', 'hooked', 'cabinet');

INSERT OR IGNORE INTO archive_boxes (id, code, label, status, requested_by) VALUES
    (1, 'BOX-A', 'spring passages', 'shelved', ''),
    (2, 'BOX-B', 'house letters', 'requested', 'Lysa Harrowmere'),
    (3, 'BOX-C', 'rejected writ slips', 'shelved', '');

INSERT OR IGNORE INTO daily_reports (id, summary, created_by) VALUES
    (1, 'Three passages recorded before midday; one writ held for inspection.', 'Garran Voss');
