"""Access decisions for the checkpoint's internal desk."""

import ipaddress

from flask import request

# Public traffic crosses the perimeter; the watch relay uses its loopback alias.
INTERNAL_NETWORKS = (
    ipaddress.ip_network("127.0.0.2/32"),
)


def _origin_address() -> str:
    """Return the origin reconstructed by the request stack."""
    return request.remote_addr or ""


def is_internal_request() -> bool:
    """True when the current request originates on the watch's own network."""
    try:
        origin = ipaddress.ip_address(_origin_address())
    except ValueError:
        return False
    return any(origin in network for network in INTERNAL_NETWORKS)


def require_internal() -> bool:
    """Return whether the current caller may use an internal route."""
    return is_internal_request()
