"""Sign and verify timestamped checkpoint writs."""

import os

from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

# Deployment overrides this development key through the environment.
WRIT_KEY = os.getenv("WRIT_KEY", "salt-gate-writ-key")

# Keep writ signatures in a separate namespace from other signed artifacts.
WRIT_SALT = "salt-gate.writ.v1"

# Writs expire at the end of an eight-hour trading day.
WRIT_MAX_AGE = 8 * 60 * 60

_serializer = URLSafeTimedSerializer(secret_key=WRIT_KEY, salt=WRIT_SALT)


def seal_writ(serial: str, bearer: str, house_id: int) -> str:
    """Seal a writ for a bearer and return the signed token."""
    return _serializer.dumps({"serial": serial, "bearer": bearer, "house_id": house_id})


def verify_writ(token: str) -> dict | None:
    """Return the payload of an authentic, unexpired writ."""
    try:
        return _serializer.loads(token, max_age=WRIT_MAX_AGE)
    except (BadSignature, SignatureExpired):
        return None
