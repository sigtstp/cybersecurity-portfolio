"""
Salt Gate checkpoint routes.

Outer face (public):
    GET  /              -- the checkpoint ledger
    POST /gate/present  -- a courier presents a writ to be let through
    GET  /gate/inspect  -- verify a writ's seal without recording a passage

Inner face (inside the wall only):
    POST /gate/decree   -- seal a binding crown decree at the inner desk

The inner desk mints crown authority. It must only ever be reached by the
gate's own internal runners, never by a courier on the road.
"""

from flask import Blueprint, request, render_template, jsonify, abort

from . import auth, gate, models

gate_bp = Blueprint(
    "gate", __name__,
    url_prefix="/app",
    static_folder="static",
    static_url_path="/app/static",
)


@gate_bp.route("/", methods=["GET"])
def ledger():
    """The public checkpoint ledger: recent passages and the houses on file."""
    return render_template(
        "ledger.html",
        passages=models.recent_passages(),
        houses=models.list_houses(),
        sealed=models.count_decrees(),
    )


@gate_bp.route("/gate/present", methods=["POST"])
def present():
    """A courier presents a writ. If its seal is authentic, record passage."""
    token = (request.form.get("writ") or "").strip()
    if not token:
        return render_template("result.html", ok=False,
                               message="No writ was presented at the gate.")

    payload = auth.verify_writ(token)
    if payload is None:
        return render_template("result.html", ok=False,
                               message="The seal on this writ does not hold. Turned away.")

    writ = models.get_writ(payload.get("serial", ""))
    if writ is None:
        return render_template("result.html", ok=False,
                               message="No such writ is on the gate's ledger.")

    models.record_passage(writ["serial"], writ["bearer"], writ["house"], "PASSED")
    return render_template("result.html", ok=True,
                           message=f"{writ['bearer']} of {writ['house']} passed the Salt Gate.",
                           writ=writ)


@gate_bp.route("/gate/inspect", methods=["GET"])
def inspect():
    """Verify a writ's seal without recording a passage. Returns JSON."""
    token = (request.args.get("writ") or "").strip()
    payload = auth.verify_writ(token) if token else None
    if payload is None:
        return jsonify({"authentic": False})

    writ = models.get_writ(payload.get("serial", ""))
    return jsonify({
        "authentic": writ is not None,
        "serial": writ["serial"] if writ else None,
        "bearer": writ["bearer"] if writ else None,
        "house": writ["house"] if writ else None,
    })


@gate_bp.route("/gate/decree", methods=["POST"])
def decree():
    """Inner desk: seal a binding crown decree for the watch.

    Sealing a decree turns a watch order into something the realm must honour,
    so the desk is open to internal watch traffic only.
    """
    if not gate.require_internal():
        abort(403)

    order = (request.form.get("order") or request.json and request.json.get("order") or "").strip()
    serial = (request.form.get("serial") or "inner-desk").strip()
    if not order:
        return jsonify({"sealed": False, "reason": "a decree needs an order to bind"}), 400

    number = models.seal_decree(serial, order, "watch-relay")
    return jsonify({
        "sealed": True,
        "decree": number,
        "order": order,
        "authority": "CROWN",
    })
