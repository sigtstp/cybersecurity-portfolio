"""Staff-session helpers for the browser console."""

from functools import wraps

from flask import abort, redirect, request, session, url_for
from werkzeug.security import check_password_hash

from . import models


def authenticate(username: str, password: str) -> dict | None:
    """Verify a staff username/password pair."""
    user = models.staff_user(username.strip())
    if user is None:
        return None
    if not check_password_hash(user["pass_hash"], password):
        return None
    return user


def sign_in(user: dict) -> None:
    """Persist the staff identity in the Flask session."""
    session.clear()
    session["staff_id"] = user["id"]


def sign_out() -> None:
    """Clear the current staff session."""
    session.clear()


def current_user() -> dict | None:
    """Return the signed-in staff account, if any."""
    user_id = session.get("staff_id")
    if user_id is None:
        return None
    return models.staff_user_by_id(int(user_id))


def require_staff(*roles: str):
    """Require a signed-in staff user, optionally limited to roles."""
    allowed = set(roles)

    def decorate(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            user = current_user()
            if user is None:
                return redirect(url_for("pages.login", next=request.path))
            if allowed and user["role"] not in allowed:
                abort(403)
            return view(*args, **kwargs)

        return wrapped

    return decorate
