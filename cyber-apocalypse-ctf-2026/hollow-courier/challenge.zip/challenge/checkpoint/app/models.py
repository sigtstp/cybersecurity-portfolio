"""
Ledger queries for the Salt Gate.

All access to the checkpoint ledger goes through these helpers so the route
layer never builds SQL by hand. Every query is parameterised.
"""

from .db import get_connection


def list_houses() -> list[dict]:
    """Return every house recognised at the gate, ordered by name."""
    connection = get_connection()
    try:
        rows = connection.execute(
            "SELECT id, name, sigil, standing FROM houses ORDER BY name"
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def get_house(house_id: int) -> dict | None:
    """Look up a single house by its id, or ``None`` if unknown."""
    connection = get_connection()
    try:
        row = connection.execute(
            "SELECT id, name, sigil, standing FROM houses WHERE id = ?",
            (house_id,),
        ).fetchone()
        return dict(row) if row else None
    finally:
        connection.close()


def writs_for_house(house_id: int) -> list[dict]:
    """Return every writ on file for a house, ordered by serial."""
    connection = get_connection()
    try:
        rows = connection.execute(
            "SELECT serial, bearer FROM writs WHERE house_id = ? ORDER BY serial",
            (house_id,),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def passages_for_house(house: str, limit: int = 12) -> list[dict]:
    """Return the most recent passages recorded for a named house."""
    connection = get_connection()
    try:
        rows = connection.execute(
            """
            SELECT serial, bearer, house, verdict, recorded_at
            FROM passages
            WHERE house = ?
            ORDER BY id DESC
            LIMIT ?
            """,
            (house, limit),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def count_houses() -> int:
    """How many houses are recognised at the gate."""
    connection = get_connection()
    try:
        return connection.execute("SELECT COUNT(*) FROM houses").fetchone()[0]
    finally:
        connection.close()


def count_passages() -> int:
    """How many passages have been recorded at the checkpoint."""
    connection = get_connection()
    try:
        return connection.execute("SELECT COUNT(*) FROM passages").fetchone()[0]
    finally:
        connection.close()


def staff_user(username: str) -> dict | None:
    """Return a staff account by username."""
    connection = get_connection()
    try:
        row = connection.execute(
            """
            SELECT id, username, display_name, role, pass_hash
            FROM staff_users
            WHERE username = ?
            """,
            (username,),
        ).fetchone()
        return dict(row) if row else None
    finally:
        connection.close()


def staff_user_by_id(user_id: int) -> dict | None:
    """Return a staff account by numeric id."""
    connection = get_connection()
    try:
        row = connection.execute(
            """
            SELECT id, username, display_name, role
            FROM staff_users
            WHERE id = ?
            """,
            (user_id,),
        ).fetchone()
        return dict(row) if row else None
    finally:
        connection.close()


def staff_count() -> int:
    """How many staff accounts are seeded for the console."""
    connection = get_connection()
    try:
        return connection.execute("SELECT COUNT(*) FROM staff_users").fetchone()[0]
    finally:
        connection.close()


def passage_summary() -> dict:
    """Small operational summary for the watch desk."""
    connection = get_connection()
    try:
        row = connection.execute(
            """
            SELECT
              COUNT(*) AS total,
              SUM(CASE WHEN verdict = 'PASSED' THEN 1 ELSE 0 END) AS passed,
              SUM(CASE WHEN verdict != 'PASSED' THEN 1 ELSE 0 END) AS stopped
            FROM passages
            """
        ).fetchone()
        return {
            "total": row["total"] or 0,
            "passed": row["passed"] or 0,
            "stopped": row["stopped"] or 0,
        }
    finally:
        connection.close()


def get_writ(serial: str) -> dict | None:
    """Look up a single writ by its serial, or ``None`` if unknown."""
    connection = get_connection()
    try:
        row = connection.execute(
            """
            SELECT w.serial, w.bearer, w.house_id, h.name AS house, h.sigil
            FROM writs w
            JOIN houses h ON h.id = w.house_id
            WHERE w.serial = ?
            """,
            (serial,),
        ).fetchone()
        return dict(row) if row else None
    finally:
        connection.close()


def recent_passages(limit: int = 12) -> list[dict]:
    """Return the most recent passages recorded at the checkpoint."""
    connection = get_connection()
    try:
        rows = connection.execute(
            """
            SELECT p.serial, p.bearer, p.house, p.verdict, p.recorded_at
            FROM passages p
            ORDER BY p.id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def record_passage(serial: str, bearer: str, house: str, verdict: str) -> None:
    """Append a passage verdict to the ledger."""
    connection = get_connection()
    try:
        connection.execute(
            "INSERT INTO passages (serial, bearer, house, verdict) VALUES (?, ?, ?, ?)",
            (serial, bearer, house, verdict),
        )
        connection.commit()
    finally:
        connection.close()


def count_decrees() -> int:
    """How many crown decrees have been sealed at the inner desk."""
    connection = get_connection()
    try:
        return connection.execute("SELECT COUNT(*) FROM decrees").fetchone()[0]
    finally:
        connection.close()


def seal_decree(serial: str, order: str, authority: str) -> int:
    """Seal a new crown decree at the inner desk and return its number."""
    connection = get_connection()
    try:
        cursor = connection.execute(
            "INSERT INTO decrees (writ_serial, decree_order, sealed_by) VALUES (?, ?, ?)",
            (serial, order, authority),
        )
        connection.commit()
        return cursor.lastrowid
    finally:
        connection.close()


def list_public_notices(limit: int = 12) -> list[dict]:
    connection = get_connection()
    try:
        rows = connection.execute(
            """
            SELECT title, body, posted_by, posted_at
            FROM public_notices
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def add_public_notice(title: str, body: str, posted_by: str) -> None:
    connection = get_connection()
    try:
        connection.execute(
            "INSERT INTO public_notices (title, body, posted_by) VALUES (?, ?, ?)",
            (title, body, posted_by),
        )
        connection.commit()
    finally:
        connection.close()


def list_shift_notes(limit: int = 10) -> list[dict]:
    connection = get_connection()
    try:
        rows = connection.execute(
            """
            SELECT note, posted_by, created_at
            FROM shift_notes
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def add_shift_note(note: str, posted_by: str) -> None:
    connection = get_connection()
    try:
        connection.execute(
            "INSERT INTO shift_notes (note, posted_by) VALUES (?, ?)",
            (note, posted_by),
        )
        connection.commit()
    finally:
        connection.close()


def list_incidents(limit: int = 12) -> list[dict]:
    connection = get_connection()
    try:
        rows = connection.execute(
            """
            SELECT id, summary, severity, status, reported_by, created_at
            FROM incidents
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def add_incident(summary: str, severity: str, reported_by: str) -> None:
    connection = get_connection()
    try:
        connection.execute(
            """
            INSERT INTO incidents (summary, severity, reported_by)
            VALUES (?, ?, ?)
            """,
            (summary, severity, reported_by),
        )
        connection.commit()
    finally:
        connection.close()


def list_supplies() -> list[dict]:
    connection = get_connection()
    try:
        rows = connection.execute(
            "SELECT id, item, quantity, unit, updated_at FROM supplies ORDER BY item"
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def adjust_supply(item_id: int, delta: int) -> None:
    connection = get_connection()
    try:
        connection.execute(
            """
            UPDATE supplies
            SET quantity = MAX(quantity + ?, 0),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (delta, item_id),
        )
        connection.commit()
    finally:
        connection.close()


def list_manifests(limit: int = 12) -> list[dict]:
    connection = get_connection()
    try:
        rows = connection.execute(
            """
            SELECT cart, house, goods, status, recorded_by, created_at
            FROM manifests
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def add_manifest(cart: str, house: str, goods: str, recorded_by: str) -> None:
    connection = get_connection()
    try:
        connection.execute(
            """
            INSERT INTO manifests (cart, house, goods, recorded_by)
            VALUES (?, ?, ?, ?)
            """,
            (cart, house, goods, recorded_by),
        )
        connection.commit()
    finally:
        connection.close()


def list_inspections() -> list[dict]:
    connection = get_connection()
    try:
        rows = connection.execute(
            """
            SELECT id, writ_serial, reason, status, assigned_to, updated_at
            FROM inspections
            ORDER BY id DESC
            """
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def update_inspection(inspection_id: int, status: str, assigned_to: str) -> None:
    connection = get_connection()
    try:
        connection.execute(
            """
            UPDATE inspections
            SET status = ?, assigned_to = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (status, assigned_to, inspection_id),
        )
        connection.commit()
    finally:
        connection.close()


def list_keys() -> list[dict]:
    connection = get_connection()
    try:
        rows = connection.execute(
            "SELECT id, label, status, holder, updated_at FROM key_register ORDER BY label"
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def update_key(key_id: int, status: str, holder: str) -> None:
    connection = get_connection()
    try:
        connection.execute(
            """
            UPDATE key_register
            SET status = ?, holder = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (status, holder, key_id),
        )
        connection.commit()
    finally:
        connection.close()


def list_archive_boxes() -> list[dict]:
    connection = get_connection()
    try:
        rows = connection.execute(
            """
            SELECT id, code, label, status, requested_by, updated_at
            FROM archive_boxes
            ORDER BY code
            """
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def update_archive_box(box_id: int, status: str, requested_by: str) -> None:
    connection = get_connection()
    try:
        connection.execute(
            """
            UPDATE archive_boxes
            SET status = ?, requested_by = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (status, requested_by, box_id),
        )
        connection.commit()
    finally:
        connection.close()


def list_daily_reports(limit: int = 8) -> list[dict]:
    connection = get_connection()
    try:
        rows = connection.execute(
            """
            SELECT summary, created_by, created_at
            FROM daily_reports
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def add_daily_report(summary: str, created_by: str) -> None:
    connection = get_connection()
    try:
        connection.execute(
            "INSERT INTO daily_reports (summary, created_by) VALUES (?, ?)",
            (summary, created_by),
        )
        connection.commit()
    finally:
        connection.close()
