"""SQLite access for the checkpoint ledger."""

import os
import sqlite3

# Tests and deployment override the default path through GATE_DB.
DB_PATH = os.getenv("GATE_DB", os.path.join(os.path.dirname(__file__), "..", "gate.db"))

SEED_PATH = os.path.join(os.path.dirname(__file__), "..", "seed.sql")


def get_connection() -> sqlite3.Connection:
    """Open a connection with row access by column name."""
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def init_db() -> None:
    """Create and seed the ledger if it does not yet exist.

    Idempotent: the seed script uses ``CREATE TABLE IF NOT EXISTS`` and
    ``INSERT OR IGNORE`` so repeated start-ups leave the ledger untouched.
    """
    with open(SEED_PATH, "r", encoding="utf-8") as handle:
        script = handle.read()

    connection = get_connection()
    try:
        connection.executescript(script)
        connection.commit()
    finally:
        connection.close()
