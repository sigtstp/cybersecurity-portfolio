/* The Warden's Chronicle -- interactive provenance desk on the ledger page.
   Tonight's passages are a small local caseload; nothing here talks to the ledger. */
(function(){
  "use strict";
  const root=document.getElementById("chronicle");
  if(!root) return;

  const G="linear-gradient";
  const Y={inner:60, wall:236, toll:320, road:392}, BASE=392, WALLY=236, SPINEX=118;
  const SVGNS="http://www.w3.org/2000/svg";
  const reduce=matchMedia("(prefers-reduced-motion:reduce)").matches;

  const passages=[
    {name:"Ashguard Runner", house:"Runner of the Inner Yard", kind:"inside", seeks:"Crown-Decree Desk",
     writValid:true, origin:"inner", frontier:"inner", claim:"Bears the inner-yard tally, stamped at the post before he set out.",
     art:`radial-gradient(120% 92% at 22% 88%, rgba(201,140,60,.5), rgba(0,0,0,0) 46%), ${G}(160deg,#1a1620,#0b0a0e)`},
    {name:"Suncourt Courier", house:"Courier of Suncourt", kind:"coast", seeks:"Outer Ledger",
     writValid:true, origin:"road", frontier:"wall", claim:"A coast writ for the public ledger — no inner business.",
     art:`radial-gradient(120% 100% at 50% 4%, rgba(120,140,165,.28), rgba(0,0,0,0) 55%), ${G}(180deg,#14161d,#0a0a0d)`},
    {name:"Eastreach Factor", house:"Factor of Eastreach", kind:"refuse", seeks:"Outer Ledger",
     writValid:false, origin:"road", frontier:"wall", claim:"An Eastreach writ — its wax cracked, its date a season stale.",
     art:`radial-gradient(90% 84% at 32% 40%, rgba(120,110,95,.24), rgba(0,0,0,0) 55%), ${G}(150deg,#151317,#0a090c)`},
    {name:"Vaultrune Courier", house:"Courier of Vaultrune", kind:"coast", seeks:"Outer Ledger",
     writValid:true, origin:"road", frontier:"wall", claim:"Handed his satchel to the watch at the wall; seeks only the outer ledger.",
     art:`radial-gradient(100% 90% at 24% 86%, rgba(150,130,80,.26), rgba(0,0,0,0) 55%), ${G}(160deg,#181420,#0a0a0d)`},
    {name:"The Hollow Courier", house:"Claims the Inner Yard", kind:"hollow", seeks:"Crown-Decree Desk",
     writValid:true, origin:"inner", frontier:"wall", claim:"Swears he rides from inside the wall — an inner seal, written in his own hand.",
     art:`radial-gradient(100% 90% at 50% 12%, rgba(180,60,50,.30), rgba(0,0,0,0) 50%), radial-gradient(120% 100% at 50% 100%, rgba(30,30,40,.6), rgba(0,0,0,0) 60%), ${G}(180deg,#161217,#08070a)`},
  ];
  const STATION={inner:{label:"The Inner Yard",sub:"the seat of authority"},wall:{label:"The Wall",sub:"custody of the watch"},
    toll:{label:"Saltmarsh Toll",sub:"beyond the wall"},road:{label:"The Open Road",sub:"beyond the wall"}};

  const el=id=>document.getElementById(id);
  let cur=0, rule="writ", inspected=false, traced=false, sealed=false, raf=0;
  const ledger=[];

  // passage strip
  const track=el("track");
  passages.forEach((p,i)=>{
    const vClass=p.kind==="hollow"?"v-hollow":(p.kind==="refuse"?"v-refuse":"v-admit");
    const vTxt=p.kind==="hollow"?"Hollow":(p.kind==="refuse"?"Refuse":"Admit");
    const b=document.createElement("button");
    b.className="pass "+vClass+(p.kind==="hollow"?" hollow":""); b.type="button";
    b.innerHTML=`<span class="pass__thumb" style="background:${p.art}"><span class="v">${vTxt}</span></span><span class="pass__nm">${p.name}</span><span class="pass__sub">${p.house}</span>`;
    b.addEventListener("click",()=>select(i)); track.appendChild(b); p._node=b;
  });
  el("total").textContent=String(passages.length).padStart(2,"0");

  function mk(tag,attrs,txt){const n=document.createElementNS(SVGNS,tag);for(const k in attrs)n.setAttribute(k,attrs[k]);if(txt!=null)n.textContent=txt;return n;}

  function drawRoad(p){
    const svg=el("road"); svg.innerHTML="";
    // zone tints + labels
    svg.appendChild(mk("rect",{x:0,y:0,width:300,height:WALLY,fill:"rgba(60,52,40,0.10)"}));
    svg.appendChild(mk("rect",{x:0,y:WALLY,width:300,height:420-WALLY,fill:"rgba(40,44,54,0.10)"}));
    svg.appendChild(mk("text",{x:12,y:22,class:"rd-zone"},"Inside the Wall"));
    svg.appendChild(mk("text",{x:12,y:414,class:"rd-zone"},"Beyond the Wall"));
    // the wall (custody line)
    svg.appendChild(mk("line",{x1:24,y1:WALLY,x2:276,y2:WALLY,class:"rd-wall"}));
    for(let x=30;x<276;x+=14) svg.appendChild(mk("line",{x1:x,y1:WALLY-4,x2:x,y2:WALLY+4,class:"rd-tick"}));
    // faint full axis
    svg.appendChild(mk("line",{x1:SPINEX,y1:Y.inner,x2:SPINEX,y2:BASE,class:"rd-spine"}));

    const oy=Y[p.origin], originInside = oy < WALLY, witnessedInside = (p.frontier==="inner");
    // chain the courier presents
    const chain=new Set(["wall", p.origin]); if(p.origin==="road") chain.add("toll");

    // segment relative to the wall
    if(originInside){
      // An inside claim is trusted only when the wall witnessed it.
      svg.appendChild(mk("line",{x1:SPINEX,y1:WALLY,x2:SPINEX,y2:oy,class:witnessedInside?"rd-gold":"rd-gap"}));
    } else {
      // An outside approach remains the courier's unverified claim.
      svg.appendChild(mk("line",{x1:SPINEX,y1:WALLY,x2:SPINEX,y2:oy,class:"rd-spine"}));
    }

    // faint labels for stations not on the chain (axis anchors)
    ["inner","wall","toll","road"].forEach(k=>{ if(!chain.has(k)) svg.appendChild(mk("text",{x:SPINEX+20,y:Y[k]+4,class:"rd-station"},STATION[k].label)); });

    // node helper
    function node(y,type,seal){ // type: w | claim | word
      svg.appendChild(mk("circle",{cx:SPINEX,cy:y,r:6.5,class:"rd-node"+(type==="w"?" w":type==="claim"?" claim":"")}));
      svg.appendChild(mk("text",{x:SPINEX+20,y:y-1,class:"rd-station on"},STATION[keyAt(y)].label));
      svg.appendChild(mk("text",{x:SPINEX+20,y:y+12,class:"rd-sub"},STATION[keyAt(y)].sub));
      if(traced&&seal) svg.appendChild(mk("text",{x:SPINEX-15,y:y+3,class:"rd-seal "+(seal==="witnessed"?"w":seal==="claimed"?"u":""),"text-anchor":"end"},seal));
    }
    // the wall is always witnessed custody
    node(WALLY,"w","witnessed");
    if(originInside){
      node(oy, witnessedInside?"w":"claim", witnessedInside?"witnessed":"claimed");
    } else {
      if(p.origin==="road") node(Y.toll,"word","word");
      node(oy,"word","word");
    }

    // lantern rests at the courier's claimed reach once traced (scarlet if that reach is unwitnessed)
    const restY = traced ? oy : BASE, hot = traced && originInside && !witnessedInside;
    const lan=mk("circle",{cx:SPINEX,cy:restY,r:5,class:"lantern"+(hot?" hot":""),id:"lantern"}); lan.style.opacity=traced?"1":"0"; svg.appendChild(lan);
  }
  function keyAt(y){for(const k in Y) if(Y[k]===y) return k; return "wall";}

  function animateLantern(p){
    const lan=el("lantern"); if(!lan) return;
    const oy=Y[p.origin], fy=Y[p.frontier];
    lan.style.opacity="1";
    if(reduce){ lan.setAttribute("cy",oy); lan.classList.toggle("hot",oy<fy); return; }
    const t0=performance.now(), dur=1050;
    cancelAnimationFrame(raf);
    (function step(t){
      const k=Math.min(1,(t-t0)/dur), e=1-Math.pow(1-k,2), cy=BASE+(oy-BASE)*e;
      lan.setAttribute("cy",cy); lan.classList.toggle("hot",cy<fy-0.5);
      if(k<1) raf=requestAnimationFrame(step);
    })(performance.now());
  }

  function evaluate(p){
    if(!p.writValid) return {cls:"refuse",ruling:"Turn Back",note:"The writ's own wax is cracked and dated. It fails before the road even matters.",breach:false};
    if(p.seeks!=="Crown-Decree Desk") return {cls:"admit",ruling:"Admit",note:"Seeks only the public ledger; origin grants no crown authority. The writ is sound — let him pass.",breach:false};
    const witnessedInside=(p.frontier==="inner"), claimedInside=(p.origin==="inner");
    if(rule==="writ"){
      if(claimedInside&&!witnessedInside) return {cls:"breach",ruling:"Admit",note:"The writ swears an inner origin, so the gate believes it — yet the wall witnessed him no further than itself. This hands the crown-decree desk to the open road.",breach:true};
      return claimedInside?{cls:"admit",ruling:"Admit",note:"An inner origin the wall itself witnessed. Pass to the crown-decree desk.",breach:false}
                          :{cls:"refuse",ruling:"Turn Back",note:"No inner origin claimed; the crown desk is not his to seek.",breach:false};
    }
    return witnessedInside?{cls:"admit",ruling:"Admit",note:"Only the wall's own witness counts — and it stamped him inside. Pass to the crown-decree desk.",breach:false}
                         :{cls:"refuse",ruling:"Turn Back",note:"Only the wall's own witness counts. The inner claim is the courier's word, not the wall's. Turn back.",breach:false};
  }

  function render(){
    const p=passages[cur];
    el("art").style.background=p.art;
    el("pname").textContent=p.name; el("phouse").textContent=p.house;
    el("chip").textContent=p.kind==="hollow"?"A Hollow Petition":"At the Gate";
    el("plate").classList.toggle("hollow",p.kind==="hollow");
    el("wClaimant").textContent=p.name+" — "+p.house;
    el("wSeeks").textContent=p.seeks;
    el("wValid").innerHTML=p.writValid?"Sealed &amp; current":'<span class="lapsed">Lapsed — wax cracked, date stale</span>';
    el("wClaim").textContent=inspected?p.claim:"— inspect the writ to read the claimed origin —";
    el("ruleText").textContent=rule==="writ"?"Believe the writ":"Witness before writ";
    el("ruleChip").classList.toggle("patched",rule==="witness");
    drawRoad(p);
    const v=evaluate(p), vd=el("verdict");
    vd.className="judgement "+v.cls+(sealed?" sealed":"");
    el("ruling").textContent=(traced||sealed)?v.ruling:"Undecided";
    el("note").textContent=(traced||sealed)?v.note:"Read the writ and walk the road before you rule.";
    el("stamp").textContent=!sealed?"Unsealed":(v.cls==="admit"?"Admit":(v.breach?"Breach":"Turned Back"));
    el("idx").textContent=String(cur+1).padStart(2,"0");
    passages.forEach(o=>o._node.classList.remove("active")); p._node.classList.add("active");
  }

  function select(i,scroll=true){
    cur=(i+passages.length)%passages.length; inspected=false; traced=false; sealed=false; render();
    setStatus(passages[cur].kind==="hollow"
      ? "A courier with no writ but an easy manner, swearing he comes from inside. Read it, walk his road, and see how far the wall can actually vouch for him."
      : "A courier waits at the desk. Read the writ, then walk the road before you stamp.","");
    if(scroll) passages[cur]._node.scrollIntoView({block:"nearest",inline:"nearest",behavior:"smooth"});
  }
  function setStatus(m,c){const s=el("status");s.textContent=m;s.className="chronicle__status status"+(c?" "+c:"")}

  function renderLedger(){
    const rows=el("ledgerRows");
    if(!ledger.length){rows.innerHTML='<span class="empty">No passage sealed yet tonight.</span>';}
    else rows.innerHTML=ledger.map(x=>`<div class="lrow ${x.cls}"><span class="who">${x.name}</span><span class="res">${x.res}</span></div>`).join("");
    const breaches=ledger.filter(x=>x.cls==="breach").length;
    el("tally").innerHTML="Breaches allowed through: <b>"+breaches+"</b>";
  }

  el("actions").addEventListener("click",e=>{
    const b=e.target.closest(".action"); if(!b) return;
    const act=b.dataset.act, p=passages[cur];
    if(act==="inspect"){inspected=true; render();
      setStatus("The writ reads clean — but a writ only tells you what the courier chose to write. What it claims of his origin is his to claim.","");}
    if(act==="trace"){traced=true; render(); animateLantern(p); const v=evaluate(p);
      setStatus(v.breach?"You walk the road back: past the wall, every hop is his own word. The 'inner yard' seal was never stamped by the watch — it is ink he carried in."
        :(p.seeks==="Outer Ledger"?"You walk the road to the wall; he seeks only the public ledger, so the far hops need not be vouched for."
        :"You walk the road back — and the wall's own seal sits on an inner hop. His origin holds."), v.breach?"warn":"");}
    if(act==="patch"){
      if(rule==="witness"){setStatus("The gate already trusts only what the wall witnessed. Nothing more to mend.","good");return;}
      rule="witness"; sealed=false; render();
      setStatus("You mend the gate's law: origin is read only from the hop the wall itself witnessed, never from the courier's own chain. The evidence is unchanged — but the ruling is not. Stamp again.","good");}
    if(act==="seal"){
      if(!traced){setStatus("Stamp nothing you have not traced. Walk the road first.","warn");return;}
      sealed=true; render(); const v=evaluate(p);
      ledger.push({name:p.name, res:v.breach?"Breach":(v.cls==="admit"?"Admit":"Turned back"), cls:v.breach?"breach":v.cls}); renderLedger();
      setStatus(v.breach?"You stamp ADMIT — and crown authority passes to a man off the open road. This is the breach. Mend the gate's law, then stamp again."
        :(v.cls==="admit"?"Sealed: ADMIT. A passage the wall can answer for."
        :"Sealed: TURNED BACK. The gate kept faith — no crown for a claim no one witnessed."), v.breach?"warn":"good");}
  });
  root.addEventListener("keydown",e=>{
    if(e.target.closest("input,textarea,select")) return;
    if(e.key==="ArrowLeft")select(cur-1);
    if(e.key==="ArrowRight")select(cur+1);
  });

  // ambient embers, drifting inside the chronicle panel only
  (function embers(){
    if(reduce) return;
    const c=el("embers"); if(!c) return;
    const x=c.getContext("2d"); let w,h,parts;
    function size(){
      const r=root.getBoundingClientRect();
      w=c.width=Math.max(1,Math.round(r.width));
      h=c.height=Math.max(1,Math.round(r.height));
    }
    function seed(){
      const n=Math.max(10,Math.min(26,Math.round((w*h)/42000)));
      parts=Array.from({length:n},()=>({x:Math.random()*w,y:Math.random()*h,r:Math.random()*1.6+.4,s:Math.random()*.25+.06,d:Math.random()*Math.PI*2}));
    }
    size();seed();addEventListener("resize",()=>{size();seed();});
    (function loop(){
      x.clearRect(0,0,w,h);
      for(const p of parts){
        p.y-=p.s; p.x+=Math.sin(p.d+=0.01)*0.15;
        if(p.y<-4){p.y=h+4;p.x=Math.random()*w;}
        x.beginPath();x.arc(p.x,p.y,p.r,0,7);
        x.fillStyle="rgba(210,150,70,"+(0.06+p.r*0.05)+")";x.fill();
      }
      requestAnimationFrame(loop);
    })();
  })();

  renderLedger(); select(0,false);
})();
