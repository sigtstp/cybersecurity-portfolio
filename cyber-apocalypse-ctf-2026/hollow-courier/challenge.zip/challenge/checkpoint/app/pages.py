"""
Informational and registry-reading pages for the Salt Gate.

These are the read-only faces of the checkpoint: the Watch's standing orders,
a house's dossier, and a small status probe for whatever sits in front of the
gate. None of them change the ledger -- the gate's decisions live in
``routes.py`` -- so they are kept apart from the gate's own blueprint.
"""

from flask import Blueprint, render_template, jsonify, abort, redirect, request, url_for

from . import models, staff

pages_bp = Blueprint("pages", __name__, url_prefix="/app")


PUBLIC_PAGES = {
    "map": {
        "title": "Gate Map",
        "kicker": "outer approach",
        "body": "A static sketch of the public road, holding yard, and ledger window.",
        "items": ["North road marker", "Salt cart lane", "Courier waiting rail"],
    },
    "notices": {
        "title": "Public Notices",
        "kicker": "posted board",
        "body": "Checkpoint notices posted for couriers approaching the gate.",
        "items": ["Trading day seals expire at dusk", "Damaged writs are inspected at the ledger window"],
    },
}


STAFF_PAGES = {
    "roster": {
        "title": "Watch Roster",
        "kicker": "staff schedule",
        "body": "Read-only staff roster for the outer face of the Salt Gate.",
        "items": ["Dawn: Ashguard Gate-Watch", "Midday: Lysa Harrowmere", "Dusk: Garran Voss"],
    },
    "shifts": {
        "title": "Shift Handover",
        "kicker": "watch desk",
        "body": "Routine notes carried between gate shifts.",
        "items": ["Count blank writ slips", "Confirm lantern oil"],
    },
    "incidents": {
        "title": "Incident Board",
        "kicker": "watch notes",
        "body": "Minor checkpoint events that do not change the passage ledger.",
        "items": ["Loose cart pin at low road", "Unreadable wax seal returned"],
    },
    "supplies": {
        "title": "Supply Register",
        "kicker": "stores",
        "body": "Desk supplies and gate stores tracked by the Watch.",
        "items": ["Ink cakes", "Salt paper", "Brass tags"],
    },
    "signals": {
        "title": "Signal Flags",
        "kicker": "wall signals",
        "body": "Reference flags for normal gate communication.",
        "items": ["Blue: ledger runner requested", "Brass: house clerk waiting", "Rust: gate held"],
    },
    "weather": {
        "title": "Road Weather",
        "kicker": "outer road",
        "body": "Road conditions copied from the morning slate.",
        "items": ["Low road: dry", "East ditch: passable", "Salt wind: moderate"],
    },
    "manifests": {
        "title": "Cart Manifests",
        "kicker": "goods desk",
        "body": "Cart manifests waiting at the goods desk.",
        "items": ["Salt sacks", "Tin lamps", "Ash barrels"],
    },
    "inspections": {
        "title": "Inspection Queue",
        "kicker": "outer face",
        "body": "Damaged or doubtful writs waiting for a watch decision.",
        "items": ["Smudged seal", "Wrong house mark", "Expired trading day"],
    },
}


PRIVILEGED_PAGES = {
    "keys": {
        "title": "Key Cabinet",
        "kicker": "clerk record",
        "body": "Inventory labels for physical desk keys. No secrets are stored here.",
        "items": ["Ledger cabinet: checked", "Lamp room: checked", "Archive drawer: checked"],
    },
    "archives": {
        "title": "Archive Index",
        "kicker": "record room",
        "body": "Reference index for boxed paper records held by the Watch.",
        "items": ["Box A: spring passages", "Box B: house letters", "Box C: rejected writ slips"],
    },
    "reports": {
        "title": "Captain Reports",
        "kicker": "command desk",
        "body": "Daily report headings prepared for clerk and captain review.",
        "items": ["Traffic summary", "Stopped writ count", "House exceptions"],
    },
}


def _staff_name() -> str:
    user = staff.current_user()
    return user["display_name"] if user else "public desk"


def _clean(name: str, limit: int = 160) -> str:
    return (request.form.get(name) or "").strip()[:limit]


def render_operations_page(page: dict, **context):
    """Render one of the operational console pages."""
    return render_template("operations.html", page=page, **context)


@pages_bp.route("/charter", methods=["GET"])
def charter():
    """The Watch's standing orders, posted at the outer face of the gate."""
    return render_template("charter.html")


@pages_bp.route("/houses/<int:house_id>", methods=["GET"])
def house(house_id: int):
    """A house's dossier: its writs on file and recent passages at the gate."""
    record = models.get_house(house_id)
    if record is None:
        abort(404)

    return render_template(
        "house.html",
        house=record,
        writs=models.writs_for_house(house_id),
        passages=models.passages_for_house(record["name"]),
    )


@pages_bp.route("/status", methods=["GET"])
def status():
    """Lightweight readiness probe for the perimeter proxy. Counts only."""
    return jsonify({
        "service": "salt-gate",
        "status": "ok",
        "houses": models.count_houses(),
        "writs_passed": models.count_passages(),
        "decrees_sealed": models.count_decrees(),
    })


@pages_bp.route("/map", methods=["GET"])
def map_board():
    """Public gate map and approach notes."""
    return render_operations_page(PUBLIC_PAGES["map"])


@pages_bp.route("/notices", methods=["GET", "POST"])
def notices():
    """Public notice board."""
    if request.method == "POST":
        if staff.current_user() is None:
            return redirect(url_for("pages.login", next=request.path))
        title = _clean("title", 80)
        body = _clean("body", 240)
        if title and body:
            models.add_public_notice(title, body, _staff_name())
        return redirect(url_for("pages.notices"))

    return render_operations_page(
        PUBLIC_PAGES["notices"],
        records=models.list_public_notices(),
        form={
            "heading": "Post Notice",
            "action": url_for("pages.notices"),
            "fields": [
                {"name": "title", "label": "Notice title", "type": "text"},
                {"name": "body", "label": "Notice body", "type": "textarea"},
            ],
            "button": "Post notice",
            "staff_only": True,
        },
    )


@pages_bp.route("/login", methods=["GET", "POST"])
def login():
    """Staff sign-in for the browser console."""
    if request.method == "POST":
        user = staff.authenticate(
            request.form.get("username", ""),
            request.form.get("password", ""),
        )
        if user is None:
            return render_template("login.html", error="Unknown staff name or passphrase."), 401
        staff.sign_in(user)
        return redirect(request.form.get("next") or url_for("pages.watch"))

    return render_template("login.html", next=request.args.get("next", ""))


@pages_bp.route("/logout", methods=["POST"])
def logout():
    """End the current staff session."""
    staff.sign_out()
    return redirect(url_for("gate.ledger"))


@pages_bp.route("/watch", methods=["GET"])
@staff.require_staff()
def watch():
    """Authenticated watch desk with operational counts and recent passages."""
    return render_template(
        "watch.html",
        summary=models.passage_summary(),
        passages=models.recent_passages(8),
        houses=models.list_houses(),
        staff_pages=STAFF_PAGES,
        privileged_pages=PRIVILEGED_PAGES,
    )


@pages_bp.route("/audit", methods=["GET"])
@staff.require_staff("clerk", "captain")
def audit():
    """Clerk/captain audit page for role-aware browser navigation."""
    return render_template(
        "audit.html",
        passages=models.recent_passages(20),
        staff_count=models.staff_count(),
    )


@pages_bp.route("/roster", methods=["GET"])
@staff.require_staff()
def roster():
    """Routine staff roster."""
    return render_operations_page(STAFF_PAGES["roster"])


@pages_bp.route("/shifts", methods=["GET", "POST"])
@staff.require_staff()
def shifts():
    """Shift handover notes."""
    if request.method == "POST":
        note = _clean("note", 240)
        if note:
            models.add_shift_note(note, _staff_name())
        return redirect(url_for("pages.shifts"))
    return render_operations_page(
        STAFF_PAGES["shifts"],
        records=models.list_shift_notes(),
        form={
            "heading": "Add Handover Note",
            "action": url_for("pages.shifts"),
            "fields": [{"name": "note", "label": "Watch note", "type": "textarea"}],
            "button": "Record note",
        },
    )


@pages_bp.route("/incidents", methods=["GET", "POST"])
@staff.require_staff()
def incidents():
    """Minor incident board."""
    if request.method == "POST":
        summary = _clean("summary", 180)
        severity = _clean("severity", 20) or "low"
        if severity not in {"low", "medium", "high"}:
            severity = "low"
        if summary:
            models.add_incident(summary, severity, _staff_name())
        return redirect(url_for("pages.incidents"))
    return render_operations_page(
        STAFF_PAGES["incidents"],
        records=models.list_incidents(),
        form={
            "heading": "File Incident",
            "action": url_for("pages.incidents"),
            "fields": [
                {"name": "summary", "label": "Incident summary", "type": "text"},
                {"name": "severity", "label": "Severity", "type": "select",
                 "options": ["low", "medium", "high"]},
            ],
            "button": "File incident",
        },
    )


@pages_bp.route("/supplies", methods=["GET", "POST"])
@staff.require_staff()
def supplies():
    """Supply register."""
    if request.method == "POST":
        try:
            item_id = int(request.form.get("item_id", "0"))
            delta = int(request.form.get("delta", "0"))
        except ValueError:
            item_id, delta = 0, 0
        if item_id and delta:
            models.adjust_supply(item_id, delta)
        return redirect(url_for("pages.supplies"))
    return render_operations_page(
        STAFF_PAGES["supplies"],
        supplies=models.list_supplies(),
        form={
            "heading": "Adjust Stores",
            "action": url_for("pages.supplies"),
            "fields": [
                {"name": "item_id", "label": "Supply", "type": "select",
                 "options": [(s["id"], s["item"]) for s in models.list_supplies()]},
                {"name": "delta", "label": "Count change", "type": "number"},
            ],
            "button": "Update stores",
        },
    )


@pages_bp.route("/signals", methods=["GET"])
@staff.require_staff()
def signals():
    """Signal flag reference."""
    return render_operations_page(STAFF_PAGES["signals"])


@pages_bp.route("/weather", methods=["GET"])
@staff.require_staff()
def weather():
    """Road weather board."""
    return render_operations_page(STAFF_PAGES["weather"])


@pages_bp.route("/manifests", methods=["GET", "POST"])
@staff.require_staff()
def manifests():
    """Cart manifest categories."""
    if request.method == "POST":
        cart = _clean("cart", 40).upper()
        house = _clean("house", 80)
        goods = _clean("goods", 200)
        if cart and house and goods:
            models.add_manifest(cart, house, goods, _staff_name())
        return redirect(url_for("pages.manifests"))
    return render_operations_page(
        STAFF_PAGES["manifests"],
        records=models.list_manifests(),
        form={
            "heading": "Register Cart",
            "action": url_for("pages.manifests"),
            "fields": [
                {"name": "cart", "label": "Cart mark", "type": "text"},
                {"name": "house", "label": "House", "type": "text"},
                {"name": "goods", "label": "Goods", "type": "textarea"},
            ],
            "button": "Register manifest",
        },
    )


@pages_bp.route("/inspections", methods=["GET", "POST"])
@staff.require_staff()
def inspections():
    """Inspection queue categories."""
    if request.method == "POST":
        try:
            inspection_id = int(request.form.get("inspection_id", "0"))
        except ValueError:
            inspection_id = 0
        status = _clean("status", 20)
        if status not in {"waiting", "cleared", "held"}:
            status = "waiting"
        if inspection_id:
            models.update_inspection(inspection_id, status, _staff_name())
        return redirect(url_for("pages.inspections"))
    inspections_list = models.list_inspections()
    return render_operations_page(
        STAFF_PAGES["inspections"],
        inspections=inspections_list,
        form={
            "heading": "Set Inspection Result",
            "action": url_for("pages.inspections"),
            "fields": [
                {"name": "inspection_id", "label": "Writ", "type": "select",
                 "options": [(i["id"], f'{i["writ_serial"]} - {i["reason"]}') for i in inspections_list]},
                {"name": "status", "label": "Decision", "type": "select",
                 "options": ["waiting", "cleared", "held"]},
            ],
            "button": "Update inspection",
        },
    )


@pages_bp.route("/keys", methods=["GET", "POST"])
@staff.require_staff("clerk", "captain")
def keys():
    """Physical key cabinet labels."""
    if request.method == "POST":
        try:
            key_id = int(request.form.get("key_id", "0"))
        except ValueError:
            key_id = 0
        status = _clean("status", 20)
        if status not in {"hooked", "issued"}:
            status = "hooked"
        holder = _staff_name() if status == "issued" else "cabinet"
        if key_id:
            models.update_key(key_id, status, holder)
        return redirect(url_for("pages.keys"))
    keys_list = models.list_keys()
    return render_operations_page(
        PRIVILEGED_PAGES["keys"],
        keys=keys_list,
        form={
            "heading": "Move Key",
            "action": url_for("pages.keys"),
            "fields": [
                {"name": "key_id", "label": "Key", "type": "select",
                 "options": [(k["id"], k["label"]) for k in keys_list]},
                {"name": "status", "label": "State", "type": "select",
                 "options": ["hooked", "issued"]},
            ],
            "button": "Update key",
        },
    )


@pages_bp.route("/archives", methods=["GET", "POST"])
@staff.require_staff("clerk", "captain")
def archives():
    """Archive index."""
    if request.method == "POST":
        try:
            box_id = int(request.form.get("box_id", "0"))
        except ValueError:
            box_id = 0
        status = _clean("status", 20)
        if status not in {"shelved", "requested"}:
            status = "shelved"
        requested_by = _staff_name() if status == "requested" else ""
        if box_id:
            models.update_archive_box(box_id, status, requested_by)
        return redirect(url_for("pages.archives"))
    boxes = models.list_archive_boxes()
    return render_operations_page(
        PRIVILEGED_PAGES["archives"],
        boxes=boxes,
        form={
            "heading": "Request Box",
            "action": url_for("pages.archives"),
            "fields": [
                {"name": "box_id", "label": "Archive box", "type": "select",
                 "options": [(b["id"], f'{b["code"]} - {b["label"]}') for b in boxes]},
                {"name": "status", "label": "State", "type": "select",
                 "options": ["shelved", "requested"]},
            ],
            "button": "Update archive",
        },
    )


@pages_bp.route("/reports", methods=["GET", "POST"])
@staff.require_staff("clerk", "captain")
def reports():
    """Captain report headings."""
    if request.method == "POST":
        summary = _clean("summary", 280)
        if summary:
            models.add_daily_report(summary, _staff_name())
        return redirect(url_for("pages.reports"))
    return render_operations_page(
        PRIVILEGED_PAGES["reports"],
        records=models.list_daily_reports(),
        form={
            "heading": "Draft Daily Report",
            "action": url_for("pages.reports"),
            "fields": [{"name": "summary", "label": "Report summary", "type": "textarea"}],
            "button": "File report",
        },
    )
