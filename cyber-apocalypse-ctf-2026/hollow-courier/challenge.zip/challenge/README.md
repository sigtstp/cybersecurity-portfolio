# Secure Coding Challenge

This repository contains the source code for The Hollow Courier. Your task is
to identify and fix the security issue without breaking the checkpoint's normal
behavior.

## Access

The running application is available at:

```text
http://[IP]:[PORT]/app
```

Clone the repository with the supplied developer account:

```bash
git clone http://htb_developer:HTBDeveloperPassword@[IP]:[PORT]/git/core_application.git
cd core_application
git checkout -b developer
```

Direct pushes to `main` are disabled. Submit all work through the `developer`
branch.

## Repository Layout

```text
checkpoint/
|-- app/               # Flask application
|-- conf/Caddyfile     # application perimeter
|-- tests/             # application tests
|-- requirements.txt
`-- seed.sql
```

## Local Development

The repository includes a local Dockerfile:

```bash
docker build -t hollow-courier checkpoint
docker run --rm -p 8000:8000 hollow-courier
```

The application is then available at `http://127.0.0.1:8000/app/`.

Run the test image with:

```bash
docker build --target test -t hollow-courier-test checkpoint
docker run --rm hollow-courier-test
```

To run the Flask service and tests without Docker:

```bash
cd checkpoint
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements-dev.txt
pytest
python wsgi.py
```

The native development server listens on `127.0.0.1:5000`. Use the Docker
workflow when testing behavior that depends on the Caddy boundary.

## Submission Workflow

Make the required changes, test them, then commit and push:

```bash
git add <changed-files>
git commit -m "describe the security fix"
git push -u origin developer
```

The push creates a pull request automatically. Review its status and feedback
at:

```text
http://[IP]:[PORT]/pulls
```

Submit a new commit for each revised attempt.

## Scoring

The hard score covers build success, required functionality, and security
checks. A full score of 60 out of 60 is required.

The soft score evaluates the quality of the submitted patch:

| Objective | Maximum | Required |
|---|---:|---:|
| Code quality | 15 | 12 |
| Security reasoning | 15 | 12 |
| Patch correctness | 10 | 6 |
| Total soft score | 40 | 28 |

Passing requires both the complete hard score and the minimum soft score.

## Flag

After the pull request is accepted, retrieve the flag from:

```bash
curl -s http://[IP]:[PORT]/flag | jq
```

The endpoint does not disclose the flag before the required score is reached.
